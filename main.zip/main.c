#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int totaldata = 0;
char sandi[512];

struct Karyawan
{
    int id;
    char nama[512];
    char posisi[512];
    char alamat[512];
    char telepon[512];
    char email[512];
    char masuk[512];
    char lahir[512];

    enum Type
    {
        Int,
        Float
    } typeAngka;
    union Angka
    {
        int i;
        float f;
    } gaji;
    enum Jenis
    {
        Rupiah,
        Dollar
    } mataUang;
};
struct Dat
{
    struct Karyawan *karyawan;
};

int u = 0;
int udcr(int s, int g)
{
    // if (s == '\n'){
    //     printf("HEREEEEEEEE-");
    //  }
    //   printf("[When u is %d]Transform %c to ", u, s);
    s ^= (sandi[u % g] ^ u ^ g);
    u += 1;
    //   printf("%c by udcr()\n", s);
    return s;
}
/*void dcr(char *s)
{
    printf(s);
    int g = strlen(sandi);
    int gs = strlen(s);
    int i = 0;
    while (1)
    {
        if (i == gs)
        {
            s[i] = '\n';
            s[i] ^= sandi[i % g] ^ i ^ g;
            s[i + 1] = '\0';
            break;
        }
        s[i] ^= sandi[i % g] ^ i;
        i++;
    }
    printf("->Hasil: %s(%d)\n", s, strlen(s));
}*/

void clear()
{
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}
void rremove(struct Dat *dat)
{
    clear();
    printf("Masukan id data karyawan yang ingin dihapus: ");
    int y = 0;
    scanf("%d", &y);
    struct Karyawan a;
    a.nama[0] = '\0';
    dat->karyawan[y] = a;
    clear();
    printf("Berhasil menghapus data.\n");
}
void display(struct Dat *dat, int a, char *string, int b, int c)
{
    clear();
    int found = 0;
    for (int i = 0; i < totaldata; i++)
    {
        if (dat->karyawan[i].nama[0] != '\0' && (a == -1 || dat->karyawan[i].id == a) && (string[0] == '\0' || strstr(dat->karyawan[i].nama, string)) && (b == -1 || c == -1 || dat->karyawan[i].id >= b && dat->karyawan[i].id <= c))
        {
            printf("ID: %d\nNama: %s\nPosisi: %s\nAlamat: %s\nNomor Telepon: %s\nEmail: %s\nTanggal Masuk Kerja: %s\nTanggal Lahir: %s\n", dat->karyawan[i].id, dat->karyawan[i].nama, dat->karyawan[i].posisi, dat->karyawan[i].alamat, dat->karyawan[i].telepon, dat->karyawan[i].email, dat->karyawan[i].masuk, dat->karyawan[i].lahir);
            if (dat->karyawan[i].typeAngka == 0)
            {
                printf("Gaji: %d", dat->karyawan[i].gaji.i);
            }
            else
            {
                printf("Gaji: %.2f", dat->karyawan[i].gaji.f);
            }
            if (dat->karyawan[i].mataUang == 0)
            {
                printf(" Rupiah (%d)\n", dat->karyawan[i].typeAngka);
            }
            else
            {
                printf(" Dollar (%d)\n", dat->karyawan[i].typeAngka);
            }
            printf("===========================\n");
            found = 1;
        }
    }
    if (!found)
    {
        printf("Tidak ditemukan.\n");
    }
    printf("\n");
    return;
}
void edit(struct Dat *dat)
{
    clear();
    printf("Masukan id karyawan yang akan diedit: ");
    int oy = 0;
    scanf("%d", &oy);
    if (dat->karyawan[oy].nama[0] != '\0')
    {
        display(dat, oy, "", -1, -1);
        int y = 0;
        printf("Pilih variable yang akan diedit:\n1. Id\n2. Nama\n3. Posisi\n4. Alamat\n5. Telepon\n6. Email\n7. Tanggal Masuk\n8. Tanggal Lahir\n9. Gaji\nInput: ");
        while (y > 9 || y < 1)
        {
            scanf("%d", &y);
        }
        while (getchar() != '\n')
            ;
        switch (y)
        {
        case 1:
            y = -1;
            printf("Masukan id: ");
            while (y > totaldata || y < 0)
            {
                scanf("%d", &y);
            }
            if (dat->karyawan[y].nama[0] != '\0')
            {
                clear();
                printf("Id tersebut telah digunakan.");
                break;
            }
            dat->karyawan[oy].id = y;
            dat->karyawan[y] = dat->karyawan[oy];
            struct Karyawan jj;
            jj.nama[0] = '\0';
            dat->karyawan[oy] = jj;
            clear();
            printf("Berhasil diedit");
            break;
        case 2:
            printf("Masukan nama: ");
            char b[512];
            fgets(b, 512, stdin);
            while (b[0] == '\n')
            {
                fgets(b, 512, stdin);
            };
            b[strcspn(b, "\n")] = '\0';
            strcpy(dat->karyawan[oy].nama, b);
            clear();
            printf("Berhasil diedit");
            break;
        case 3:
            printf("Masukan posisi: ");
            char b1[512];
            fgets(b1, 512, stdin);
            while (b1[0] == '\n')
            {
                fgets(b1, 512, stdin);
            };
            b1[strcspn(b1, "\n")] = '\0';
            strcpy(dat->karyawan[oy].posisi, b1);
            clear();
            printf("Berhasil diedit");
            break;
        case 4:
            printf("Masukan alamat: ");
            char b2[512];
            fgets(b2, 512, stdin);
            while (b2[0] == '\n')
            {
                fgets(b2, 512, stdin);
            };
            b2[strcspn(b2, "\n")] = '\0';
            strcpy(dat->karyawan[oy].alamat, b2);
            clear();
            printf("Berhasil diedit");
            break;
        case 5:
            printf("Masukan telepon: ");
            char b3[512];
            fgets(b3, 512, stdin);
            while (b3[0] == '\n')
            {
                fgets(b3, 512, stdin);
            };
            b3[strcspn(b3, "\n")] = '\0';
            strcpy(dat->karyawan[oy].telepon, b3);
            clear();
            printf("Berhasil diedit");
            break;
        case 6:
            printf("Masukan email: ");
            char b4[512];
            fgets(b4, 512, stdin);
            while (b4[0] == '\n')
            {
                fgets(b4, 512, stdin);
            };
            b4[strcspn(b4, "\n")] = '\0';
            strcpy(dat->karyawan[oy].email, b4);
            clear();
            printf("Berhasil diedit");
            break;
        case 7:
            printf("Masukan tanggal masuk: ");
            char b5[512];
            fgets(b5, 512, stdin);
            while (b5[0] == '\n')
            {
                fgets(b5, 512, stdin);
            };
            b5[strcspn(b5, "\n")] = '\0';
            strcpy(dat->karyawan[oy].masuk, b5);
            clear();
            printf("Berhasil diedit");
            break;
        case 8:
            printf("Masukan tanggal lahir: ");
            char b6[512];
            fgets(b6, 512, stdin);
            while (b6[0] == '\n')
            {
                fgets(b6, 512, stdin);
            };
            b6[strcspn(b6, "\n")] = '\0';
            strcpy(dat->karyawan[oy].lahir, b6);
            clear();
            printf("Berhasil diedit");
            break;
        case 9:
            printf("Pilih mata uang gaji: \n1. Rupiah\n2. Dollar\nPilihan: ");
            while (y > 2 || y < 1)
            {
                scanf("%d", &y);
            }
            dat->karyawan[oy].mataUang = y;
            int yy = 0;
            printf("Pilih type variable angka:\n1. Int\n2. Float\nPilihan: ");
            while (yy > 2 || yy < 1)
            {
                scanf("%d", &yy);
            }
            if (yy == 1)
            {
                printf("Masukan nominal gaji: ");
                int g = 0;
                scanf("%d", &g);
                dat->karyawan[oy].gaji.i = g;
            }
            else
            {
                printf("Masukan nominal gaji(desimal): ");
                char t[512];
                while (getchar() != '\n')
                    ;
                fgets(t, 512, stdin);
                t[strcspn(t, "\n")] = '\0';
                dat->karyawan[oy].gaji.f = atof(t);
            }
            clear();
            printf("Berhasil diedit.");
            break;
        }
        printf("\n");
    }
    else
    {
        clear();
        printf("Data tidak ditemukan.\n");
    }
}

void add(struct Dat *dat)
{
    clear();

    struct Karyawan k;
    printf("Masukan nama: ");
    char name[512];
    fgets(name, 512, stdin);
    name[strcspn(name, "\n")] = '\0';
    strcpy(k.nama, name);
    printf("Masukan posisi: ");
    fgets(name, 512, stdin);
    name[strcspn(name, "\n")] = '\0';
    strcpy(k.posisi, name);
    printf("Masukan alamat: ");
    fgets(name, 512, stdin);
    name[strcspn(name, "\n")] = '\0';
    strcpy(k.alamat, name);
    printf("Masukan telepon: ");
    fgets(name, 512, stdin);
    name[strcspn(name, "\n")] = '\0';
    strcpy(k.telepon, name);
    printf("Masukan email: ");
    fgets(name, 512, stdin);
    name[strcspn(name, "\n")] = '\0';
    strcpy(k.email, name);
    printf("Masukan tanggal masuk kerja: ");
    fgets(name, 512, stdin);
    name[strcspn(name, "\n")] = '\0';
    strcpy(k.masuk, name);
    printf("Masukan tanggal lahir: ");
    fgets(name, 512, stdin);
    name[strcspn(name, "\n")] = '\0';
    strcpy(k.lahir, name);
    printf("Masukan type gaji:\n1. Int\n2. Float\nPilihan: ");
    int gg = -1;
    while (gg > 2 || gg < 1)
    {
        if (scanf("%d", &gg) <= 0)
        {
            while (getchar() != '\n')
                ;
        }
    }
    k.typeAngka = gg - 1;

    if (gg == 1)
    {
        printf("Masukan angka gaji(int): ");
        gg = -1;
        while (gg < 0)
        {
            if (scanf("%d", &gg) <= 0)
            {
                while (getchar() != '\n')
                    ;
            }
        }
        k.gaji.i = gg;
    }
    else
    {
        printf("Masukan angka gaji(float): ");
        char t[512];
        while (getchar() != '\n')
            ;
        fgets(t, 512, stdin);
        t[strcspn(t, "\n")] = '\0';
        k.gaji.f = atof(t);
    }
    printf("Masukan type gaji:\n1. Rupiah\n2. Dollar\nPilihan: ");
    gg = 0;
    while (gg > 2 || gg < 1)
    {
        if (scanf("%d", &gg) <= 0)
        {

            while (getchar() != '\n')
                ;
        }
    }
    k.mataUang = gg - 1;
    for (int i = 0; i < totaldata; i++)
    {
        if (dat->karyawan[i].nama[0] == '\0')
        {
            k.id = i;
            dat->karyawan[i] = k;
            clear();
            printf("Data ditambahkan ke id-%d\n", i);
            break;
        }
    }
}

void refresh(struct Dat *dat)
{
    clear();
    FILE *g = fopen("Dat.dzt", "rb");
    char buffer[512] = "";
    int buff;
    int dtrack = 0;
    int did = -1;
    for (int s = 0; s < totaldata; s++)
    {
        dat->karyawan[s].nama[0] = '\0';
    }
    int o = 2;
    int dg = strlen(sandi);
    while ((buff = fgetc(g)) != EOF)
    {
        int bufff = udcr(buff, dg);
        if (bufff != '\n')
        {
            int h = strlen(buffer);
            buffer[h] = bufff;
            buffer[h + 1] = '\0';
            continue;
        }
        u = 0;
        if (o > 0)
        {
            o--;
            buffer[0] = '\0';
            continue;
        }
        dtrack++;
        // printf("When u is finish this line: %s(dtrack: %d)\n", buffer, dtrack);
        switch (dtrack)
        {
        case 1:
            did = atoi(buffer);
            struct Karyawan a;
            dat->karyawan[did] = a;
            dat->karyawan[did].id = did;
            break;
        case 2:

            strcpy(dat->karyawan[did].nama, buffer);
            break;
        case 3:

            strcpy(dat->karyawan[did].posisi, buffer);
            break;
        case 4:

            strcpy(dat->karyawan[did].alamat, buffer);
            break;
        case 5:

            strcpy(dat->karyawan[did].telepon, buffer);
            break;
        case 6:

            strcpy(dat->karyawan[did].email, buffer);
            break;
        case 7:

            strcpy(dat->karyawan[did].masuk, buffer);
            break;
        case 8:

            strcpy(dat->karyawan[did].lahir, buffer);
            break;
        case 9:
            dat->karyawan[did].typeAngka = atoi(buffer);
            break;
        case 10:
            if (dat->karyawan[did].typeAngka == 0)
            {
                dat->karyawan[did].gaji.i = atoi(buffer);
            }
            else
            {
                dat->karyawan[did].gaji.f = atof(buffer);
            }
            break;
        case 11:
            dat->karyawan[did].mataUang = atoi(buffer);
            dtrack = 0;
            break;
        }
        buffer[0] = '\0';
    }
    // if (feof(g))
    // {
    //      printf("EOF\n");
    //  }
    //  if (ferror(g))
    //  {
    //      printf("Something wrong.\n");
    //  }
    // printf("Refresh: Stropped");
    u = 0;
}
void save(struct Dat *dat)
{
    clear();
    FILE *g;
    g = fopen("Dat.dzt", "wb");
    if (g == NULL)
    {
        printf("Pembacaan file error/File Dat.dzt tidak ditemukan.\n");
        return;
    }
    fclose(g);
    int y = strlen(sandi);
    g = fopen("Dat.dzt", "ab");
    char buffer[512] = "";
    char k[] = "HellooWorldd!!\n";
    while (u < 15)
    {
        fprintf(g, "%c", udcr(k[u], y));
    }
    u = 0;
    sprintf(buffer, "%d\n", totaldata);
    int ok = strlen(buffer);
    while (u < ok)
    {
        fprintf(g, "%c", udcr(buffer[u], y));
    }
    u = 0;
    // printf("TotalData: %i", totaldata);
    for (int j = 0; j < totaldata; j++)
    {
        if (dat->karyawan[j].nama[0] == '\0')
        {
            continue;
        }

        sprintf(buffer, "%d\n", dat->karyawan[j].id);
        ok = strlen(buffer);
        while (u < ok)
        {
            fprintf(g, "%c", udcr(buffer[u], y));
        }
        u = 0;
        strcpy(buffer, dat->karyawan[j].nama);
        strcat(buffer, "\n");
        ok = strlen(buffer);
        while (u < ok)
        {
            fprintf(g, "%c", udcr(buffer[u], y));
        }
        u = 0;
        strcpy(buffer, dat->karyawan[j].posisi);
        strcat(buffer, "\n");
        ok = strlen(buffer);
        while (u < ok)
        {
            fprintf(g, "%c", udcr(buffer[u], y));
        }
        u = 0;
        strcpy(buffer, dat->karyawan[j].alamat);
        strcat(buffer, "\n");
        ok = strlen(buffer);
        while (u < ok)
        {
            fprintf(g, "%c", udcr(buffer[u], y));
        }
        u = 0;
        strcpy(buffer, dat->karyawan[j].telepon);
        strcat(buffer, "\n");
        ok = strlen(buffer);
        while (u < ok)
        {
            fprintf(g, "%c", udcr(buffer[u], y));
        }
        u = 0;
        strcpy(buffer, dat->karyawan[j].email);
        strcat(buffer, "\n");
        ok = strlen(buffer);
        while (u < ok)
        {
            fprintf(g, "%c", udcr(buffer[u], y));
        }
        u = 0;
        strcpy(buffer, dat->karyawan[j].masuk);
        strcat(buffer, "\n");
        ok = strlen(buffer);
        while (u < ok)
        {
            fprintf(g, "%c", udcr(buffer[u], y));
        }
        u = 0;
        strcpy(buffer, dat->karyawan[j].lahir);
        strcat(buffer, "\n");
        ok = strlen(buffer);
        while (u < ok)
        {
            fprintf(g, "%c", udcr(buffer[u], y));
        }
        u = 0;
        sprintf(buffer, "%d\n", dat->karyawan[j].typeAngka);
        ok = strlen(buffer);
        while (u < ok)
        {
            fprintf(g, "%c", udcr(buffer[u], y));
        }
        u = 0;
        if (dat->karyawan[j].typeAngka == 0)
        {
            sprintf(buffer, "%d\n", dat->karyawan[j].gaji.i);

            ok = strlen(buffer);
            while (u < ok)
            {
                fprintf(g, "%c", udcr(buffer[u], y));
            }
        }
        else
        {
            sprintf(buffer, "%.2f\n", dat->karyawan[j].gaji.f);
            ok = strlen(buffer);
            while (u < ok)
            {
                fprintf(g, "%c", udcr(buffer[u], y));
            }
        }
        u = 0;
        sprintf(buffer, "%d\n", dat->karyawan[j].mataUang);
        ok = strlen(buffer);
        while (u < ok)
        {
            fprintf(g, "%c", udcr(buffer[u], y));
        }
        u = 0;
    }
    printf("Berhasil disimpan\n");
    fclose(g);
}
int pass = 0;
int main()
{

    FILE *j = fopen("Dat.dzt", "rb");
    struct Dat dat;
    if (j == NULL)
    {
        fclose(j);
        printf("[Pengelola Data Karyawan]\n1. Buat data baru\n2. Exit\nInput: ");
        int gg = 0;
        while (gg > 2 || gg < 1)
        {
            if (scanf("%d", &gg) <= 0)
            {
                while (getchar() != '\n')
                    ;
            }
        }
        if (gg == 2)
        {
            return 0;
        }

        gg = 0;
        printf("Masukan jumlah data yang perlu dikelola: ");
        while (gg < 1)
        {
            if (scanf("%d", &gg) <= 0)
            {
                while (getchar() != '\n')
                    ;
            }
        }
        while (getchar() != '\n')
            ;
        printf("Buat kata sandi untuk file: ");
        fgets(sandi, 512, stdin);
        sandi[strcspn(sandi, "\n")] = '\0';
        totaldata = gg;
        dat.karyawan = malloc(sizeof(struct Karyawan) * totaldata);
        if (dat.karyawan == NULL)
        {
            printf("Alokasi memori gagal.");
            return 1;
        }
        for (int s = 0; s < totaldata; s++)
        {
            dat.karyawan[s].nama[0] = '\0';
        }
        add(&dat);
        save(&dat);
        refresh(&dat);
    }
    else
    {

        if (pass == 0)
        {
            printf("[Pengelola Data Karyawan]\n1. Masukan sandi\n2. Exit\nPilihan: ");
            int gg = 0;
            while (gg > 2 || gg < 1)
            {
                if (scanf("%d", &gg) <= 0)
                {
                    while (getchar() != '\n')
                        ;
                }
            }
            if (gg == 1)
            {
                while (getchar() != '\n')
                    ;
                printf("Sandi: ");
                while (fgets(sandi, 512, stdin)[0] == '\n')
                    ;
                int ok = 0;
                sandi[strcspn(sandi, "\n")] = '\0';
                char buffer[512] = "";
                char buffer2[512];
                int t;
                int gp = 0;
                int y = strlen(sandi);
                while ((t = fgetc(j)) != EOF)
                {
                    t = udcr(t, y);
                    if (t != '\n')
                    {
                        // printf("Passin: %c\n", t);
                        int h = strlen(buffer);
                        buffer[h] = t;
                        buffer[h + 1] = '\0';
                        // printf("Updated buffer: %s\n", buffer);
                        continue;
                    }
                    // printf("Buffer input (Password/Total): %s\n", buffer);
                    u = 0;
                    if (gp == 0)
                    {
                        strcpy(buffer2, buffer);
                        // printf("The text now: %s", buffer2);
                        gp = 1;
                        buffer[0] = '\0';
                    }
                    else
                    {
                        ok = 1;
                        break;
                    }
                }
                fclose(j);
                if (ok && strcmp(buffer2, "HellooWorldd!!") == 0)
                {
                    totaldata = atoi(buffer);
                    pass = 1;
                }
                else
                {
                    u = 0;
                    clear();
                    gp = 0;
                    printf("Sandi salah\n");
                }
                main();
            }
            return 0;
        }
        dat.karyawan = malloc(sizeof(struct Karyawan) * totaldata);
        refresh(&dat);
        printf("Selamat Datang!\n");
    }

    int exit = 1;
    while (exit)
    {
        printf("[Pengelola Data Karyawan]\nOpsi:\n1. Display data karyawan\n2. Baca ulang file data\n3. Display semua data\n4. Tambah data\n5. Hapus data\n6. Edit data\n7. Save\n8. Ubah sandi\n9. Exit\nPilihan: ");
        int gg = 0;
        while (gg > 9 || gg < 1)
        {
            if (scanf("%d", &gg) <= 0)
            {

                while (getchar() != '\n')
                    ;
            }
        }
        clear();
        switch (gg)
        {
        case 1:
            printf("1. Display by name\n2. Display by id\n3. Display by id range\n0. Menu\nPilihan: ");
            gg = -1;
            while (gg > 3 || gg < 0)
            {
                if (scanf("%d", &gg) <= 0)
                {
                    while (getchar() != '\n')
                        ;
                }
            }
            if (gg == 1)
            {
                char name[512];
                printf("Masukan nama karyawan: ");
                while (getchar() != '\n')
                    ;
                fgets(name, 512, stdin);
                name[strcspn(name, "\n")] = '\0';
                display(&dat, -1, name, -1, -1);
                continue;
            }
            else if (gg == 0)
            {
                clear();
                continue;
            }
            else if (gg == 2)
            {
                gg = -1;
                printf("Masukan id: ");
                while (gg > totaldata - 1 || gg < 0)
                {
                    scanf("%d", &gg, -1);
                }
                display(&dat, gg, "", -1, -1);
                continue;
            }
            else
            {
                gg = -1;
                int gge = -1;
                printf("Masukan id awal: ");
                while (gg > totaldata - 1 || gg < 0)
                {
                    if (scanf("%d", &gg) <= 0)
                    {
                        while (getchar() != '\n')
                            ;
                    }
                }
                printf("Masukan id akhir: ");
                while (gge > totaldata - 1 || gge < 0)
                {
                    scanf("%d", &gge);
                }
                display(&dat, -1, "", gg, gge);
                continue;
            }
        case 2:
            refresh(&dat);
            continue;
        case 3:
            display(&dat, -1, "", -1, -1);
            continue;
        case 4:
            while (getchar() != '\n')
                ;
            add(&dat);
            continue;
        case 5:
            rremove(&dat);
            continue;
        case 6:
            edit(&dat);
            continue;
        case 7:
            save(&dat);
            break;
        case 8:
            clear();
            printf("Masukan sandi: ");
            while (getchar() != '\n')
                ;
            char bu[512];
            fgets(bu, 512, stdin);
            bu[strcspn(bu, "\n")] = '\0';
            if (strcmp(bu, sandi) == 0)
            {
                printf("Masukan sandi baru: ");
                fgets(sandi, 512, stdin);
                sandi[strcspn(sandi, "\n")] = '\0';
                clear();
                save(&dat);
                printf("Sandi berhasil diubah.\n");
            }
            else
            {
                clear();
                printf("Sandi salah.\n");
            }
            break;
        case 9:
            exit = 0;
            break;
        }
    }
    return 0;
}